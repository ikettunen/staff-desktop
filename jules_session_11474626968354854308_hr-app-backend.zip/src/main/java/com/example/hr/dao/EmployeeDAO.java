package com.example.hr.dao;

import com.example.hr.model.Employee;
import com.example.hr.model.Job;
import com.example.hr.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the Employee table.
 */
public class EmployeeDAO {

    /**
     * Adds a new employee to the database.
     *
     * @param employee the employee to add
     */
    public void addEmployee(Employee employee) {
        String sql = "INSERT INTO employees (employee_id, first_name, last_name, email, phone_number, hire_date, job_id, salary, commission_pct, manager_id, department_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, employee.getEmployeeId());
            pstmt.setString(2, employee.getFirstName());
            pstmt.setString(3, employee.getLastName());
            pstmt.setString(4, employee.getEmail());
            pstmt.setString(5, employee.getPhoneNumber());
            pstmt.setDate(6, employee.getHireDate());
            pstmt.setString(7, employee.getJob().getJobId());
            pstmt.setDouble(8, employee.getSalary());
            pstmt.setDouble(9, employee.getCommissionPct());
            pstmt.setInt(10, employee.getManagerId());
            pstmt.setInt(11, employee.getDepartmentId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Updates an existing employee in the database.
     *
     * @param employee the employee to update
     */
    public void updateEmployee(Employee employee) {
        String sql = "UPDATE employees SET first_name = ?, last_name = ?, email = ?, phone_number = ?, hire_date = ?, job_id = ?, salary = ?, commission_pct = ?, manager_id = ?, department_id = ? WHERE employee_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, employee.getFirstName());
            pstmt.setString(2, employee.getLastName());
            pstmt.setString(3, employee.getEmail());
            pstmt.setString(4, employee.getPhoneNumber());
            pstmt.setDate(5, employee.getHireDate());
            pstmt.setString(6, employee.getJob().getJobId());
            pstmt.setDouble(7, employee.getSalary());
            pstmt.setDouble(8, employee.getCommissionPct());
            pstmt.setInt(9, employee.getManagerId());
            pstmt.setInt(10, employee.getDepartmentId());
            pstmt.setInt(11, employee.getEmployeeId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Deletes an employee from the database.
     *
     * @param employeeId the ID of the employee to delete
     */
    public void deleteEmployee(int employeeId) {
        String sql = "DELETE FROM employees WHERE employee_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, employeeId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets an employee by their ID.
     *
     * @param employeeId the ID of the employee to retrieve
     * @return the employee, or null if not found
     */
    public Employee getEmployeeById(int employeeId) {
        String sql = "SELECT e.*, j.job_title, j.min_salary, j.max_salary FROM employees e JOIN jobs j ON e.job_id = j.job_id WHERE e.employee_id = ?";
        Employee employee = null;
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, employeeId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                employee = extractEmployeeFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employee;
    }

    /**
     * Gets a list of all employees.
     *
     * @return a list of all employees
     */
    public List<Employee> getAllEmployees() {
        String sql = "SELECT e.*, j.job_title, j.min_salary, j.max_salary FROM employees e JOIN jobs j ON e.job_id = j.job_id";
        List<Employee> employees = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                employees.add(extractEmployeeFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employees;
    }

    private Employee extractEmployeeFromResultSet(ResultSet rs) throws SQLException {
        Job job = new Job();
        job.setJobId(rs.getString("job_id"));
        job.setJobTitle(rs.getString("job_title"));
        job.setMinSalary(rs.getDouble("min_salary"));
        job.setMaxSalary(rs.getDouble("max_salary"));

        Employee employee = new Employee();
        employee.setEmployeeId(rs.getInt("employee_id"));
        employee.setFirstName(rs.getString("first_name"));
        employee.setLastName(rs.getString("last_name"));
        employee.setEmail(rs.getString("email"));
        employee.setPhoneNumber(rs.getString("phone_number"));
        employee.setHireDate(rs.getDate("hire_date"));
        employee.setJob(job);
        employee.setSalary(rs.getDouble("salary"));
        employee.setCommissionPct(rs.getDouble("commission_pct"));
        employee.setManagerId(rs.getInt("manager_id"));
        employee.setDepartmentId(rs.getInt("department_id"));
        return employee;
    }
}
