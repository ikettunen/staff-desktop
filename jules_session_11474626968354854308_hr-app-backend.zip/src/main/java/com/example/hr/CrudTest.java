package com.example.hr;

import com.example.hr.dao.EmployeeDAO;
import com.example.hr.model.Employee;
import com.example.hr.model.Job;

import java.sql.Date;
import java.util.List;

/**
 * A simple command-line application to test the CRUD operations of the EmployeeDAO.
 */
public class CrudTest {
    /**
     * The main method.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        EmployeeDAO employeeDAO = new EmployeeDAO();

        // Note: To run this test, you must first provide valid database credentials in the database.properties file.
        // You also need to ensure the database contains a job with the ID 'IT_PROG'.

        // Create a new job object for the new employee
        Job job = new Job();
        job.setJobId("IT_PROG"); // Assuming 'IT_PROG' exists in the jobs table

        // 1. Create a new employee
        System.out.println("1. Creating a new employee...");
        Employee newEmployee = new Employee();
        newEmployee.setEmployeeId(999); // A temporary ID
        newEmployee.setFirstName("John");
        newEmployee.setLastName("Doe");
        newEmployee.setEmail("john.doe@example.com");
        newEmployee.setPhoneNumber("555-1234");
        newEmployee.setHireDate(new Date(System.currentTimeMillis()));
        newEmployee.setJob(job);
        newEmployee.setSalary(60000);
        newEmployee.setCommissionPct(0);
        newEmployee.setManagerId(100); // Assuming manager with ID 100 exists
        newEmployee.setDepartmentId(60); // Assuming department with ID 60 exists

        employeeDAO.addEmployee(newEmployee);
        System.out.println("   Employee created successfully.");

        // 2. Read the employee
        System.out.println("\n2. Reading the newly created employee...");
        Employee retrievedEmployee = employeeDAO.getEmployeeById(999);
        System.out.println("   Retrieved Employee: " + retrievedEmployee);

        // 3. Update the employee
        System.out.println("\n3. Updating the employee's salary...");
        retrievedEmployee.setSalary(65000);
        employeeDAO.updateEmployee(retrievedEmployee);
        Employee updatedEmployee = employeeDAO.getEmployeeById(999);
        System.out.println("   Updated Employee: " + updatedEmployee);

        // 4. List all employees
        System.out.println("\n4. Listing all employees...");
        List<Employee> employees = employeeDAO.getAllEmployees();
        for (Employee emp : employees) {
            System.out.println("   - " + emp);
        }

        // 5. Delete the employee
        System.out.println("\n5. Deleting the employee...");
        employeeDAO.deleteEmployee(999);
        Employee deletedEmployee = employeeDAO.getEmployeeById(999);
        if (deletedEmployee == null) {
            System.out.println("   Employee deleted successfully.");
        } else {
            System.out.println("   Error: Employee was not deleted.");
        }
    }
}
