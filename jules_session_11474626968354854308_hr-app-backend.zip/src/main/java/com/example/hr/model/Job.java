package com.example.hr.model;

/**
 * Represents a job in the HR database.
 */
public class Job {
    private String jobId;
    private String jobTitle;
    private double minSalary;
    private double maxSalary;

    /**
     * Default constructor.
     */
    public Job() {
    }

    /**
     * Constructs a new Job with the specified details.
     *
     * @param jobId     the job ID
     * @param jobTitle  the job title
     * @param minSalary the minimum salary
     * @param maxSalary the maximum salary
     */
    public Job(String jobId, String jobTitle, double minSalary, double maxSalary) {
        this.jobId = jobId;
        this.jobTitle = jobTitle;
        this.minSalary = minSalary;
        this.maxSalary = maxSalary;
    }

    /**
     * Gets the job ID.
     *
     * @return the job ID
     */
    public String getJobId() {
        return jobId;
    }

    /**
     * Sets the job ID.
     *
     * @param jobId the job ID
     */
    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    /**
     * Gets the job title.
     *
     * @return the job title
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * Sets the job title.
     *
     * @param jobTitle the job title
     */
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    /**
     * Gets the minimum salary.
     *
     * @return the minimum salary
     */
    public double getMinSalary() {
        return minSalary;
    }

    /**
     * Sets the minimum salary.
     *
     * @param minSalary the minimum salary
     */
    public void setMinSalary(double minSalary) {
        this.minSalary = minSalary;
    }

    /**
     * Gets the maximum salary.
     *
     * @return the maximum salary
     */
    public double getMaxSalary() {
        return maxSalary;
    }

    /**
     * Sets the maximum salary.
     *
     * @param maxSalary the maximum salary
     */
    public void setMaxSalary(double maxSalary) {
        this.maxSalary = maxSalary;
    }

    @Override
    public String toString() {
        return "Job{" +
                "jobId='" + jobId + '\'' +
                ", jobTitle='" + jobTitle + '\'' +
                ", minSalary=" + minSalary +
                ", maxSalary=" + maxSalary +
                '}';
    }
}
