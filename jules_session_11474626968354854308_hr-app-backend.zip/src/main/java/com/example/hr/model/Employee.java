package com.example.hr.model;

import java.sql.Date;

/**
 * Represents an employee in the HR database.
 */
public class Employee {
    private int employeeId;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private Date hireDate;
    private Job job;
    private double salary;
    private double commissionPct;
    private int managerId;
    private int departmentId;

    /**
     * Default constructor.
     */
    public Employee() {
    }

    /**
     * Constructs a new Employee with the specified details.
     *
     * @param employeeId    the employee ID
     * @param firstName     the first name
     * @param lastName      the last name
     * @param email         the email address
     * @param phoneNumber   the phone number
     * @param hireDate      the hire date
     * @param job           the job
     * @param salary        the salary
     * @param commissionPct the commission percentage
     * @param managerId     the manager ID
     * @param departmentId  the department ID
     */
    public Employee(int employeeId, String firstName, String lastName, String email, String phoneNumber, Date hireDate, Job job, double salary, double commissionPct, int managerId, int departmentId) {
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.hireDate = hireDate;
        this.job = job;
        this.salary = salary;
        this.commissionPct = commissionPct;
        this.managerId = managerId;
        this.departmentId = departmentId;
    }

    // Getters and Setters

    /**
     * Gets the employee ID.
     *
     * @return the employee ID
     */
    public int getEmployeeId() {
        return employeeId;
    }

    /**
     * Sets the employee ID.
     *
     * @param employeeId the employee ID
     */
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    /**
     * Gets the first name.
     *
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the first name.
     *
     * @param firstName the first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets the last name.
     *
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the last name.
     *
     * @param lastName the last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Gets the email address.
     *
     * @return the email address
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address.
     *
     * @param email the email address
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the phone number.
     *
     * @return the phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the phone number.
     *
     * @param phoneNumber the phone number
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * Gets the hire date.
     *
     * @return the hire date
     */
    public Date getHireDate() {
        return hireDate;
    }

    /**
     * Sets the hire date.
     *
     * @param hireDate the hire date
     */
    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    /**
     * Gets the job.
     *
     * @return the job
     */
    public Job getJob() {
        return job;
    }

    /**
     * Sets the job.
     *
     * @param job the job
     */
    public void setJob(Job job) {
        this.job = job;
    }

    /**
     * Gets the salary.
     *
     * @return the salary
     */
    public double getSalary() {
        return salary;
    }

    /**
     * Sets the salary.
     *
     * @param salary the salary
     */
    public void setSalary(double salary) {
        this.salary = salary;
    }

    /**
     * Gets the commission percentage.
     *
     * @return the commission percentage
     */
    public double getCommissionPct() {
        return commissionPct;
    }

    /**
     * Sets the commission percentage.
     *
     * @param commissionPct the commission percentage
     */
    public void setCommissionPct(double commissionPct) {
        this.commissionPct = commissionPct;
    }

    /**
     * Gets the manager ID.
     *
     * @return the manager ID
     */
    public int getManagerId() {
        return managerId;
    }

    /**
     * Sets the manager ID.
     *
     * @param managerId the manager ID
     */
    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    /**
     * Gets the department ID.
     *
     * @return the department ID
     */
    public int getDepartmentId() {
        return departmentId;
    }

    /**
     * Sets the department ID.
     *
     * @param departmentId the department ID
     */
    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", hireDate=" + hireDate +
                ", job=" + job +
                ", salary=" + salary +
                ", commissionPct=" + commissionPct +
                ", managerId=" + managerId +
                ", departmentId=" + departmentId +
                '}';
    }
}
